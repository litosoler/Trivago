# IS410-II2017-ProyectoPOO-Grupo #1

## Integrantes:

+ Andrea Nicolle Valladares (__"nicollevalladares"__)
+ Denis Adonis Henriquez ("__denisadonis__")
+ Julio Ariel Guardado ("__EliteArmy__")
+ Jefry ("__DeathKira__")
+ Rafael Bautista ("__LPSoldier19__")
