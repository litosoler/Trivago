$(document).ready(function(){
	//alert("El DOM fue cargado");
/*
	$.ajax({
		url: "",
		data: "",
		method: "POST",
		success: function(resultado){
			$("").html(resultado);
		},
		error: function(){
		}
	});
*/
});

