<?php

class Nombre {
	
	protected $variable;

	public function __construct(){
	
	}

	public function __toString(){
			return ;
	}

}

?>