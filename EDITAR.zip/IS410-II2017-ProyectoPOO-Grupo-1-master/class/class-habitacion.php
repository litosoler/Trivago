<?php 
	class ClassName
	{
		protected $nombreHotel;
		protected $numCamas;
		protected $precio; // Precio por Noche
		
		function __construct(argument)
		{
			# code...
		}
	}
?>