<?php

class Administrador {
	
	protected $variable;

	public function __construct(){
	
	}

	public function __toString(){
			return ;
	}

}

?>